package ma.xproce.inventoryservice.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Creator {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String mail;

    @OneToMany(mappedBy = "creat", fetch = FetchType.EAGER)
    private Collection<Video> vid;

    public void addVideo(Video newVideo) {
        if (this.vid == null) {
            this.vid = new ArrayList<>();
        }
        this.vid.add(newVideo);
    }

    @Override
    public String toString() {
        return "Creator{" +
                "id=" + id +
                ", nom=" + name +
                ", email=" + mail +
                ", video=" + vid +
                '}';
    }
}
