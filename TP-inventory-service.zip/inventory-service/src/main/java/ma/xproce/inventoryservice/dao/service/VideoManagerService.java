package ma.xproce.inventoryservice.dao.service;

import ma.xproce.inventoryservice.dao.entities.Video;
import ma.xproce.inventoryservice.dao.repositeries.VideoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class VideoManagerService implements VideoManager{
    private final VideoDAO videoRepo;

    @Autowired
    public VideoManagerService(VideoDAO videoRepo) {
        this.videoRepo= videoRepo;
    }

    @Override
    public Video addVideo(Video video) {

        return videoRepo.save(video);
    }
    @Override
    public Video updateVideo(Video video) {
        return videoRepo.save(video);
    }

    @Override
    public boolean deleteVideo(long id) {
        videoRepo.deleteById(id);
        return true;
    }

    @Override
    public List<Video> getAllVideos() {
        return videoRepo.findAll();
    }
    public Video getVideoById(long id) {
        return videoRepo.findById(id).get();
    }


}
