package ma.xproce.inventoryservice.dao.service;

import ma.xproce.inventoryservice.dao.entities.Creator;
import ma.xproce.inventoryservice.dao.repositeries.CreatorDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CreatorManagerService implements CreatorManager{
    private final CreatorDAO creatorRepo;

    @Autowired
    public CreatorManagerService(CreatorDAO creatorRepository) {
        this.creatorRepo = creatorRepository;
    }

    @Override
    public Creator addCreator(Creator creator) {

        return creatorRepo.save(creator);
    }
    @Override
    public Creator updateCreator(Creator creator) {
        return creatorRepo.save(creator);
    }

    @Override
    public boolean deleteCreator(long id) {
        try {
            creatorRepo.deleteById(id);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    @Override
    public List<Creator> getAllCreators() {
        return creatorRepo.findAll();
    }
    @Override
    public Creator getCreatorById(long id) {
        return creatorRepo.findById(id).orElse(null);
    }

    @Override
    public Page<Creator> getAllCreators(int page, int taille) {
        return creatorRepo.findAll(PageRequest.of(page, taille));

    }

    @Override
    public Page<Creator> searchCreator(String keyword, int page, int taille){
        return creatorRepo.findByNameContains(keyword, PageRequest.of(page, taille));

    }

}
