package ma.xproce.inventoryservice;

import ma.xproce.inventoryservice.dao.entities.Creator;
import ma.xproce.inventoryservice.dao.entities.Video;
import ma.xproce.inventoryservice.dao.repositeries.CreatorDAO;
import ma.xproce.inventoryservice.dao.repositeries.VideoDAO;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class InventoryServiceApplication {
    @Bean
    CommandLineRunner start(CreatorDAO creatorDAO, VideoDAO videoDAO) {
        return args -> {
           /*  Creator creator1 = new Creator();
            creator1.setId(123);
            creator1.setName("salma");
            creator1.setMail("salma.saa@gmail.com");
            creatorDAO.save(creator1);
            Creator creator2 = new Creator();
            creator1.setId(1234);
            creator1.setName("sas");
            creator1.setMail("sas.wawa@gmail.com");
            creatorDAO.save(creator2);

            Video video1= new Video();
            video1.setId(12345);
            video1.setName("childhood memories");
            video1.setUrl("www.mychildhood.aa");

            Video video2= new Video();
            video1.setId(12346);
            video1.setName("today is a new day");
            video1.setUrl("www.test.aa");

*/
        };
    }
    public static void main(String[] args) {
        SpringApplication.run(InventoryServiceApplication.class, args);
    }

}
