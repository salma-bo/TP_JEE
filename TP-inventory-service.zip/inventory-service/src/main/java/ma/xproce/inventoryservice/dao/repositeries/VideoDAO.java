package ma.xproce.inventoryservice.dao.repositeries;


import ma.xproce.inventoryservice.dao.entities.Video;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VideoDAO extends JpaRepository<Video,Long> {
    public List<Video> findByName (String name);
}
